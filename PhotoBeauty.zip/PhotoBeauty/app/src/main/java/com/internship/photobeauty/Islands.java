package com.internship.photobeauty;

import android.content.Context;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class Islands extends Fragment {
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        RecyclerView recyclerViewIslands=(RecyclerView) inflater.inflate(R.layout.islands,container,false);
        setUpRecyclerView(recyclerViewIslands);
        return  recyclerViewIslands;
    }

    private void setUpRecyclerView(RecyclerView rv)
    {

        rv.setLayoutManager(new LinearLayoutManager(rv.getContext()));
        rv.setAdapter(new IslandsAdapter(rv.getContext(), getListForItems()));
    }

    public ArrayList<Integer> getListForItems()
    {

        ArrayList<Integer> list =new ArrayList<>();
        list.add(R.drawable.i1);
        list.add(R.drawable.i2);
        list.add(R.drawable.i3);
        list.add(R.drawable.i4);
        list.add(R.drawable.i5);
        list.add(R.drawable.i6);
        list.add(R.drawable.i7);
        list.add(R.drawable.i8);
        list.add(R.drawable.i9);
        list.add(R.drawable.i10);
        list.add(R.drawable.i11);
        list.add(R.drawable.i12);

        return list;
    }
    public  static class IslandsAdapter extends RecyclerView.Adapter<IslandsAdapter.ViewHolder>
    {
        ArrayList<Integer> aboutlist=new ArrayList<>();
        Context aboutuscontext;
        public static class ViewHolder extends RecyclerView.ViewHolder
        {
            public final ImageView items;
            public ViewHolder(View view)
            {
                super(view);
                items=view.findViewById(R.id.thumbnail);
            }
        }
        public IslandsAdapter(Context context,ArrayList<Integer> list)
        {
            aboutuscontext=context;
            aboutlist=list;
        }
        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.listitems, parent, false);
            return  new ViewHolder(view);
        }
        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            //holder.items.setText(aboutlist.get(position));
            Picasso.with(aboutuscontext).load(aboutlist.get(position)).into(holder.items, new com.squareup.picasso.Callback() {
                @Override
                public void onSuccess() {

                }

                @Override
                public void onError() {

                }
            });

        }
        @Override
        public int getItemCount() {
            return aboutlist.size();
        }
    }
}

