package com.internship.photobeauty;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class Falls  extends Fragment {
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        RecyclerView recyclerViewFalls=(RecyclerView) inflater.inflate(R.layout.falls,container,false);
        setUpRecyclerView(recyclerViewFalls);
        return  recyclerViewFalls;
    }

    private void setUpRecyclerView(RecyclerView rv)
    {

        rv.setLayoutManager(new LinearLayoutManager(rv.getContext()));
        rv.setAdapter(new FallsAdapter(rv.getContext(), getListForItems()));
    }

    public ArrayList<Integer> getListForItems()
    {

        ArrayList<Integer> list =new ArrayList<>();
        list.add(R.drawable.w1);
        list.add(R.drawable.w2);
        list.add(R.drawable.w3);
        list.add(R.drawable.w4);
        list.add(R.drawable.w5);
        list.add(R.drawable.w6);
        list.add(R.drawable.w7);
        list.add(R.drawable.w8);
        list.add(R.drawable.w9);
        list.add(R.drawable.w10);
        list.add(R.drawable.w11);
        list.add(R.drawable.w12);

        return list;
    }
    public  static class FallsAdapter extends RecyclerView.Adapter<FallsAdapter.ViewHolder>
    {
        ArrayList<Integer> aboutlist=new ArrayList<>();
        Context aboutuscontext;
        public static class ViewHolder extends RecyclerView.ViewHolder
        {
            public final ImageView items;
            public ViewHolder(View view)
            {
                super(view);
                items=view.findViewById(R.id.thumbnail);
            }
        }
        public FallsAdapter(Context context,ArrayList<Integer> list)
        {
            aboutuscontext=context;
            aboutlist=list;
        }
        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.listitems, parent, false);
            return  new ViewHolder(view);
        }
        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            //holder.items.setText(aboutlist.get(position));
            Picasso.with(aboutuscontext).load(aboutlist.get(position)).into(holder.items, new com.squareup.picasso.Callback() {
                @Override
                public void onSuccess() {

                }

                @Override
                public void onError() {

                }
            });

        }
        @Override
        public int getItemCount() {
            return aboutlist.size();
        }
    }
}

