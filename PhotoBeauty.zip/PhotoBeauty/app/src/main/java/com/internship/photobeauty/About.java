package com.internship.photobeauty;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class About extends Fragment {
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        RecyclerView recyclerView=(RecyclerView) inflater.inflate(R.layout.about,container,false);
        setUpRecyclerView(recyclerView);
        return  recyclerView;
    }
    private void setUpRecyclerView(RecyclerView rv)
    {
        rv.setLayoutManager(new LinearLayoutManager(rv.getContext()));
        rv.setAdapter(new AboutUsAdapter(rv.getContext(), getListForItems()));
    }
    public ArrayList<Integer> getListForItems()
    {
        ArrayList<Integer> list =new ArrayList<Integer>();
        list.add(R.drawable.img1);
        list.add(R.drawable.img2);
        list.add(R.drawable.img3);
        list.add(R.drawable.img4);
        list.add(R.drawable.img5);
        list.add(R.drawable.img6);
        list.add(R.drawable.img7);
        list.add(R.drawable.img8);
        list.add(R.drawable.img9);
        list.add(R.drawable.img10);
        list.add(R.drawable.img11);
        list.add(R.drawable.img12);

        return list;
    }
    public  static class AboutUsAdapter extends RecyclerView.Adapter<AboutUsAdapter.ViewHolder>
    {
        ArrayList<Integer> aboutlist=new ArrayList<>();
        Context aboutuscontext;
        private Integer place;

        public static class ViewHolder extends RecyclerView.ViewHolder
        {
            public final ImageView items;
            public ViewHolder(View view)
            {
                super(view);
                items=view.findViewById(R.id.thumbnail);
            }
        }
        public AboutUsAdapter(Context context,ArrayList<Integer> list)
        {
            aboutuscontext=context;
            aboutlist=list;
        }
        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.listitems, parent, false);
            return  new ViewHolder(view);

        }
        @Override
        public void onBindViewHolder(ViewHolder holder, final int position) {
            Picasso.with(aboutuscontext).load(aboutlist.get(position)).into(holder.items, new com.squareup.picasso.Callback() {
                @Override
                public void onSuccess() {

                }

                @Override
                public void onError() {

                }
            });
        }
        @Override
        public int getItemCount() {
            return aboutlist.size();
        }
    }
}
