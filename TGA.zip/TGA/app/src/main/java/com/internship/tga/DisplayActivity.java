package com.internship.tga;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.media.Image;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class DisplayActivity extends AppCompatActivity {

    ImageView tgaicon;
    TextView tganame;
    Button tgalink;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);
        tgaicon = findViewById(R.id.img);
        tganame = findViewById(R.id.name);
        tgalink = findViewById(R.id.store);
        Intent intent = getIntent();

        display();
    }

    private void display() {

        String img = MyAdapter.image;
        String name = MyAdapter.name;
        final String url = MyAdapter.store;
        //String name = intent.getStringExtra(MyAdapter.name);
        // final String url = intent.getStringExtra(MyAdapter.store);

        Picasso.with(this).load(img.replace("https","http")).placeholder(R.drawable.appimage).error(R.drawable.appimage).into(tgaicon, new com.squareup.picasso.Callback() {
            @Override
            public void onSuccess() {
            }

            @Override
            public void onError() {

            }
        });

        tganame.setText(name);
        tgalink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                browserIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
                startActivity(browserIntent);
            }
        });


    }

}
