package com.internship.tga.Constant;

public class BaseUrl {

    public static final String baseUrl = "https://www.thegreatapps.com/rest_api/";
}
