package com.internship.quizgame;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class HelpActivity extends AppCompatActivity {

    TextView rules;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);
        getSupportActionBar().hide();
    }

    public void homePage(View view) {
        {

            AlertDialog.Builder builder = new AlertDialog.Builder(HelpActivity.this);
            builder.setCancelable(false);
            builder.setTitle("Are you sure you want to go back to home page?");
            //builder.setMessage("Exiting will call finish() Method");
            builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int id) {
                    finish();
                }
            })
                    .setNegativeButton("NO", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                        }
                    });

            // Create the AlertDialog object and return it
            builder.create().show();
        }
    }
}
