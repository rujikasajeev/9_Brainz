package com.internship.quizgame;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import java.util.Random;

public class QuestionActivity extends AppCompatActivity implements View.OnClickListener {

    RadioGroup rg_options;
    RadioButton btn_one, btn_two, btn_three, btn_four;
    TextView tv_question;

    private Questionnaire question = new Questionnaire();

    private String answer;
    private int wrong=0;
    private int questionLength = question.questions.length;

    Random random;
    private int i = 0;
    public int score = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question);


        random = new Random();
        btn_one = findViewById(R.id.btn_one);
        btn_one.setOnClickListener(this);
        btn_two = findViewById(R.id.btn_two);
        btn_two.setOnClickListener(this);
        btn_three = findViewById(R.id.btn_three);
        btn_three.setOnClickListener(this);
        btn_four = findViewById(R.id.btn_four);
        btn_four.setOnClickListener(this);
        rg_options = findViewById(R.id.rg_options);

        tv_question = (TextView)findViewById(R.id.tv_question);

        NextQuestion(random.nextInt(questionLength));


    }


    @SuppressLint("ResourceAsColor")
    @Override
    public void onClick(View v) {
        int selectedId = rg_options.getCheckedRadioButtonId();
        v = findViewById(selectedId);
        switch (v.getId()) {
            case R.id.btn_one:
                btn_two.setEnabled(false);
                btn_three.setEnabled(false);
                btn_four.setEnabled(false);
                if(btn_one.getText() == answer){
                    btn_one.setBackground(getResources().getDrawable(R.drawable.button_correct_answer));
                    //btn_one.setButtonDrawable(getResources().getDrawable(R.drawable.correct));
                    score = score + 5;
                }else{
                    btn_one.setBackground(getResources().getDrawable(R.drawable.button_wrong_answer));
                    score = score - 5;
                    wrong = wrong + 1;
                    correctAnswer();
                }

                break;

            case R.id.btn_two:
                btn_one.setEnabled(false);
                btn_three.setEnabled(false);
                btn_four.setEnabled(false);
                if(btn_two.getText() == answer){
                    btn_two.setBackground(getResources().getDrawable(R.drawable.button_correct_answer));
                   // btn_two.setButtonDrawable(getResources().getDrawable(R.drawable.correct));
                    score = score + 5;
                }else{
                    btn_two.setBackground(getResources().getDrawable(R.drawable.button_wrong_answer));
                    score = score - 5;
                    wrong = wrong + 1;
                    correctAnswer();
                }

                break;

            case R.id.btn_three:
                btn_one.setEnabled(false);
                btn_two.setEnabled(false);
                btn_four.setEnabled(false);
                if(btn_three.getText() == answer){
                    btn_three.setBackground(getResources().getDrawable(R.drawable.button_correct_answer));
                    score = score + 5;
                }else{
                    btn_three.setBackground(getResources().getDrawable(R.drawable.button_wrong_answer));
                    score = score - 5;
                    wrong = wrong + 1;
                    correctAnswer();

                }

                break;

            case R.id.btn_four:
                btn_one.setEnabled(false);
                btn_two.setEnabled(false);
                btn_three.setEnabled(false);
                if(btn_four.getText() == answer){
                    btn_four.setBackground(getResources().getDrawable(R.drawable.button_correct_answer));
                    score = score + 5;
                }else{
                    btn_four.setBackground(getResources().getDrawable(R.drawable.button_wrong_answer));
                    score = score - 5;
                    wrong = wrong + 1;
                    correctAnswer();
                }

                break;
        }
    }

    private void correctAnswer() {

        if(btn_one.getText() == answer) {
            btn_one.setBackground(getResources().getDrawable(R.drawable.button_correct_answer));
        }
        else if(btn_two.getText() == answer) {
            btn_two.setBackground(getResources().getDrawable(R.drawable.button_correct_answer));
        }

        else if(btn_three.getText() == answer) {
            btn_three.setBackground(getResources().getDrawable(R.drawable.button_correct_answer));
        }
        else {
            btn_four.setBackground(getResources().getDrawable(R.drawable.button_correct_answer));
        }

    }

    private void NextQuestion(int num){
        i++;
        if(i != 6 && wrong != 2)  {

            btn_one.setChecked(false);
            btn_two.setChecked(false);
            btn_three.setChecked(false);
            btn_four.setChecked(false);
            btn_one.setEnabled(true);
            btn_two.setEnabled(true);
            btn_three.setEnabled(true);
            btn_four.setEnabled(true);
            tv_question.setText(question.getQuestion(num));
            btn_one.setText(question.getchoice1(num));
            btn_two.setText(question.getchoice2(num));
            btn_three.setText(question.getchoice3(num));
            btn_four.setText(question.getchoice4(num));
            answer = question.getCorrectAnswer(num);
        }
        else
        {
                Intent i = new Intent(QuestionActivity.this, ScoreActivity.class);
                Bundle extras = new Bundle();
                extras.putString("StringVariableName", score + "");
                i.putExtras(extras);
                startActivity(i);
        }

    }

    @SuppressLint("ResourceAsColor")
    public void nextQuestion(View view) {
        btn_one.setBackground(getResources().getDrawable(R.drawable.button_bg_rounded_corners));
        btn_two.setBackground(getResources().getDrawable(R.drawable.button_bg_rounded_corners));
        btn_three.setBackground(getResources().getDrawable(R.drawable.button_bg_rounded_corners));
        btn_four.setBackground(getResources().getDrawable(R.drawable.button_bg_rounded_corners));
        //btn_one.setTextColor(R.color.BLACK);
        NextQuestion(random.nextInt(questionLength));
    }

    public void homePage(View view) {

        AlertDialog.Builder builder = new AlertDialog.Builder(QuestionActivity.this);
        builder.setCancelable(false);
        builder.setTitle("Are you sure to restart your game?");
        //builder.setMessage("Exiting will call finish() Method");
        builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {
                finish();
                Intent i = new Intent(QuestionActivity.this,MenuActivity.class);
                startActivity(i);
            }
        })
                .setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

        // Create the AlertDialog object and return it
        builder.create().show();
    }

}
