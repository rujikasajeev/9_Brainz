package com.internship.quizgame;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class ScoreActivity extends AppCompatActivity {

    TextView score;
    private DBManager dbManager;
    private long _id;
    String fscore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_score);
        getSupportActionBar().hide();
        dbManager = new DBManager(this);
        dbManager.open();
        Bundle extras = getIntent().getExtras();
        String stringVariableName = extras.getString("StringVariableName");
        int finalScore = Integer.parseInt(stringVariableName);
        score = findViewById(R.id.tv_score_display);
        score.setText("Your score is "+ finalScore);

        String name = AddName.name;
        dbManager.insert(name , finalScore);
        /*Intent intent = getIntent();
        String id = intent.getStringExtra("id");
        //String name = intent.getStringExtra("title");
        String desc = intent.getStringExtra("desc");

        _id = Long.parseLong(id);
        //title = titleText.getText().toString();
        fscore = score.getText().toString();

        dbManager.update(_id, desc);*/

    }

    public void exit(View view) {

        AlertDialog.Builder builder = new AlertDialog.Builder(ScoreActivity.this);
        builder.setCancelable(false);
        builder.setTitle("Are you sure to exit?");
        //builder.setMessage("Exiting will call finish() Method");
        builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {
                finishAffinity();
                System.exit(0);
            }
        })
                .setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

        // Create the AlertDialog object and return it
        builder.create().show();
    }

    public void closeApplication(View view) {

        AlertDialog.Builder builder = new AlertDialog.Builder(ScoreActivity.this);
        builder.setCancelable(false);
        builder.setTitle("Are you sure to restart your game?");
        //builder.setMessage("Exiting will call finish() Method");
        builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {
                Intent i = new Intent(ScoreActivity.this,MenuActivity.class);
                startActivity(i);
            }
        })
                .setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

        // Create the AlertDialog object and return it
        builder.create().show();
    }
}
