package com.internship.quizgame;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class MenuActivity extends AppCompatActivity implements View.OnClickListener {

    Button play,help,exit;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        play = findViewById(R.id.play);
        help = findViewById(R.id.help);
        exit = findViewById(R.id.exit);

        setWidget();
    }

    private void setWidget() {
        play.setOnClickListener(this);
    }

    /*public void onPlay(View view) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Enter Your Name \n");

// Set up the input
        final EditText input = new EditText(this);

        input.setInputType(InputType.TYPE_CLASS_TEXT);
        builder.setView(input);

// Set up the buttons
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                m_Text = input.getText().toString();
                if(m_Text.isEmpty())
                {
                    Log.e("if part", "working");
                    Snackbar snackbar = Snackbar
                            .make(coordinatorLayout, "Please Enter Your Name", Snackbar.LENGTH_LONG)
                            .setAction("RETRY", new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    Intent i = new Intent(MenuActivity.this,MenuActivity.class);
                                    startActivity(i);
                                }
                            });
                    snackbar.show();
                    dialog.cancel();
                }
                else {
                    Log.e("else part","working");
                    UserDBHandler dbHandler = new UserDBHandler(MenuActivity.this, null, null, 1);
                    String name = input.getText().toString();
                    User user = new User(name);
                    dbHandler.addHandler(user);
                    Intent i = new Intent(MenuActivity.this, QuestionActivity.class);
                    startActivity(i);
                }

            }
        });
        builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.show();
    }*/

    public void needHelp(View view)
    {
        Intent i = new Intent(MenuActivity.this,HelpActivity.class);
        startActivity(i);
    }

    public void closeApplication(View view) {

        AlertDialog.Builder builder = new AlertDialog.Builder(MenuActivity.this);
        builder.setCancelable(false);
        builder.setTitle("Are you sure to exit?");
        //builder.setMessage("Exiting will call finish() Method");
        builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {
                finish();
            }
        })
                .setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                    }
                });

        // Create the AlertDialog object and return it
        builder.create().show();
    }

    public void highScore(View view) {

        Intent i = new Intent(MenuActivity.this,HighScoreActivity.class);
        startActivity(i);
    }

    /**
     * Called when a view has been clicked.
     *
     * @param v The view that was clicked.
     */
    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.play:
                showAlertDialoag();
                break;
        }
    }

    private void showAlertDialoag() {


        Intent i = new Intent(MenuActivity.this, AddName.class);
        startActivity(i);

    }
}
