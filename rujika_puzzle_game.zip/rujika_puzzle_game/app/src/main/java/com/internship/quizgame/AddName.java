package com.internship.quizgame;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.Snackbar;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class AddName extends Activity implements OnClickListener {

    private Button addTodoBtn;
    private EditText subjectEditText;
    private DBManager dbManager;
    public static String name;
    CoordinatorLayout coordinatorLayout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setTitle("Add Record");

        setContentView(R.layout.activity_add_name);

        subjectEditText = (EditText) findViewById(R.id.subject_edittext);

        addTodoBtn = (Button) findViewById(R.id.add_record);

        dbManager = new DBManager(this);
        dbManager.open();
        addTodoBtn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.add_record:

                 name = subjectEditText.getText().toString();

               // dbManager.insert(name);

                if(name.trim().length() > 0)
                {
                    Log.e("if part", "working");
                    Intent i = new Intent(AddName.this, QuestionActivity.class);
                    startActivity(i);

                }
                else {
                    Log.e("else part","working");
                    Snackbar snackbar;
                    snackbar = Snackbar
                            .make(coordinatorLayout, "Please Enter Your Name", Snackbar.LENGTH_LONG)
                            .setAction("RETRY", new OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    Intent i = new Intent(AddName.this,MenuActivity.class);
                                    startActivity(i);
                                }
                            });
                    snackbar.show();
                }
                break;
        }
    }

}