package com.internship.quizgame;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

public class DBManager {

    private UserDBHandler dbHelper;

    private Context context;

    private SQLiteDatabase database;

    public DBManager(Context c) {
        context = c;
    }

    public DBManager open() throws SQLException {
        dbHelper = new UserDBHandler(context);
        database = dbHelper.getWritableDatabase();
        return this;
    }

    public void close() {
        dbHelper.close();
    }

    public void insert(String name, int Score) {
        ContentValues contentValue = new ContentValues();
        contentValue.put(UserDBHandler.NAME, name);
        contentValue.put(UserDBHandler.SCORE, Score);
        database.insert(UserDBHandler.TABLE_NAME, null, contentValue);
    }

    public Cursor fetch() {
        String[] columns = new String[] { UserDBHandler._ID, UserDBHandler.NAME, UserDBHandler.SCORE };
        Cursor cursor = database.query(UserDBHandler.TABLE_NAME, columns, null, null, null, null, null);
        if (cursor != null) {
            cursor.moveToFirst();
        }
        return cursor;
    }

    public int update(long _id,  String desc) {
        ContentValues contentValues = new ContentValues();
        //contentValues.put(UserDBHandler.NAME, name);
        contentValues.put(UserDBHandler.SCORE, desc);
        int i = database.update(UserDBHandler.TABLE_NAME, contentValues, UserDBHandler._ID + " = " + _id, null);
        return i;
    }

    public void delete(long _id) {
        database.delete(UserDBHandler.TABLE_NAME, UserDBHandler._ID + "=" + _id, null);
    }

}
