package com.internship.quizgame;

public class Questionnaire {

        public String questions[] = {
                "What year did Albert Einstein die?",
                "How many Presidents have there been of the USA? (Updated 2014)",
                "What colour is Cerulean?",
                "What are a group of Dolphins called?",
                "Who has won the most Academy Awards?",
                "“Sensex” is related to",
                "Who among following was the longest serving Arab Leader ?",
                "MS Dhoni is the _______ captain of Indian Cricket Team",
                "Wal-Mart in India is associated with",
                "Which was the India’s first scheduled airline ?",
                "Which political party does Sri Ajit Singh represents ?",
                "Who among following ordered “Jallian Wala Bagh Massacre” ?"
        };

        public String choices[][] = {
                {"1954","1949","1960","1955"},
                {"36","29","46","44"},
                {"Red","Blue","Yellow","Green"},
                {"School","  Herd","Pod","Pool"},
                {"James Cameron","Walt Disney","Katherine Hepburn","Steven Spielberg"},
                {"BSE","NSE","RBI","SEBI"},
                {"King Abdullah", "Muammar Gaddafi", "Hosni Mubarak", "Bashar-al-Assad"},
                {"41th","35th","31th","34th"},
                {"Big Bazaar","Spencer's Retail","Easy Day Stores","Spur Retail"},
                {"Air India","Tata Airlines","Air Birla", "Indian Airlines"},
                {"Rashtriya Lok Dal","Samta Party","Samajwadi Party","Jan Lok Dal"},
                {"Lord Mountbatten", "John Simon","Reginald Dyer","N.D.K MacEven"}
        };

        public String correctAnswer[] = {
                "1955",
                "44",
                "Blue",
                "Pod",
                "Walt Disney",
                "BSE",
                "Muammar Gaddafi",
                "34th",
                "Spencer's Retail",
                "Tata Airlines",
                "Rashtriya Lok Dal",
                "Reginald Dyer"

        };

        public String getQuestion(int a){
            String question = questions[a];
            return question;
        }

        public String getchoice1(int a){
            String choice = choices[a][0];
            return choice;
        }

        public String getchoice2(int a){
            String choice = choices[a][1];
            return choice;
        }

        public String getchoice3(int a){
            String choice = choices[a][2];
            return choice;
        }

        public String getchoice4(int a){
            String choice = choices[a][3];
            return choice;
        }

        public String getCorrectAnswer(int a){
            String answer = correctAnswer[a];
            return answer;
        }

}
