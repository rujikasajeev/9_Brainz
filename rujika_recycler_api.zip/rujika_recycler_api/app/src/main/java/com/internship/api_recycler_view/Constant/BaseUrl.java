package com.internship.api_recycler_view.Constant;


public class BaseUrl {

    public static final String baseUrl = "http://puzzel-app.maldechavda.me/api/";
}
